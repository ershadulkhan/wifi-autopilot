package com.ershad.wifiautopilot.control

/**
 * The one rule that keeps you from being stranded without mobile data:
 * the app only switches mobile data OFF when it is sure it can switch it back ON after you leave.
 *
 * Why this matters: Shizuku is usually started through Wireless debugging. Android turns Wireless
 * debugging off the moment the phone leaves (or turns off) Wi-Fi, and when USB debugging is off too
 * it stops adb completely - and Shizuku with it (AOSP AdbDebuggingManager + AdbService.stopAdbd).
 * So with USB debugging off, Shizuku dies exactly when mobile data has to come back on.
 *
 * Pure logic, no Android calls, so it is unit-tested off the phone.
 */
object DataSafety {

    enum class Verdict {
        /** This phone switches data with the permanent permission alone (no Shizuku needed). */
        SETTINGS_OK,

        /** Shizuku is running and will survive leaving Wi-Fi (root, or USB debugging on). */
        SHIZUKU_OK,

        /** Shizuku is running now but Android will stop it when Wi-Fi drops (USB debugging off). */
        SHIZUKU_WILL_STOP,

        /** Nothing can switch the data toggle right now; Android only pauses data on Wi-Fi. */
        NO_ENGINE,
    }

    const val ROOT_UID = 0

    /**
     * @param settingsWorks the Settings.Global data switch was tested and works on this phone
     * @param shizukuReady Shizuku is running and Wi-Fi Autopilot is allowed to use it
     * @param shizukuUid uid of Shizuku's server: 0 = root, 2000 = adb shell, -1 = unknown
     * @param usbDebugging USB debugging (Settings.Global.ADB_ENABLED) is on, which keeps adb alive
     */
    fun decide(settingsWorks: Boolean, shizukuReady: Boolean, shizukuUid: Int, usbDebugging: Boolean): Verdict = when {
        settingsWorks -> Verdict.SETTINGS_OK
        !shizukuReady -> Verdict.NO_ENGINE
        shizukuUid == ROOT_UID -> Verdict.SHIZUKU_OK
        usbDebugging -> Verdict.SHIZUKU_OK
        else -> Verdict.SHIZUKU_WILL_STOP
    }

    /** Switching data OFF is only allowed when it can surely be switched back ON. Switching ON is always tried. */
    fun mayTurnDataOff(verdict: Verdict): Boolean = verdict == Verdict.SETTINGS_OK || verdict == Verdict.SHIZUKU_OK
}
