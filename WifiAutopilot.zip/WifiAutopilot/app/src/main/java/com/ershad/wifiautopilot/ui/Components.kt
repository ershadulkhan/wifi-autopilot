package com.ershad.wifiautopilot.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

// ------------------------------------------------------------------ structure

/** A section title that sits above its group, like Android's own settings. */
@Composable
fun SectionTitle(title: String, trailing: String? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 6.dp, end = 6.dp, top = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (trailing != null) {
            Text(trailing, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** A quiet tonal surface holding a list of rows. No shadow. */
@Composable
fun Group(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), content = content)
    }
}

@Composable
fun GroupDivider() {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
}

/** One line of quiet explanatory text inside a group. */
@Composable
fun GroupNote(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 10.dp),
    )
}

// ------------------------------------------------------------------ status

/** Semantic colors for the status pills. */
@Composable
fun Pill(text: String, tone: Tone) {
    val color = toneColor(tone)
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.14f),
        modifier = Modifier.widthIn(max = 200.dp),
    ) {
        Text(
            text,
            color = color,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

/** A small neutral fact, e.g. "Android 16". */
@Composable
fun Fact(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

/** Label on the left, pill on the right (the detailed status list). */
@Composable
fun StatusRow(label: String, value: String, tone: Tone) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Pill(value, tone)
    }
}

@Composable
fun ToneIcon(tone: Tone, modifier: Modifier = Modifier) {
    val icon = when (tone) {
        Tone.Good -> Icons.Filled.CheckCircle
        Tone.Warn, Tone.Bad -> Icons.Filled.Warning
        Tone.Neutral -> Icons.Filled.Info
    }
    Icon(icon, contentDescription = null, tint = toneColor(tone), modifier = modifier.size(22.dp))
}

/**
 * One core function: what it does, whether it works right now, and – only when something needs
 * doing – one button that fixes it.
 */
@Composable
fun CapabilityRow(
    title: String,
    detail: String,
    state: String,
    tone: Tone,
    actionLabel: String? = null,
    actionEnabled: Boolean = true,
    onAction: () -> Unit = {},
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        ToneIcon(tone)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                if (state.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(state, style = MaterialTheme.typography.labelLarge, color = toneColor(tone))
                }
            }
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (actionLabel != null) {
                Spacer(Modifier.height(4.dp))
                FilledTonalButton(onClick = onAction, enabled = actionEnabled) { Text(actionLabel) }
            }
        }
    }
}

/**
 * A setup step. Steps really are a sequence, so they are numbered. Finished steps shrink to one line.
 */
@Composable
fun StepRow(
    number: Int,
    title: String,
    done: Boolean,
    help: String,
    actionLabel: String?,
    onAction: () -> Unit,
    actionEnabled: Boolean = true,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = if (done) 9.dp else 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (done) {
            ToneIcon(Tone.Good, Modifier.padding(top = 1.dp))
        } else {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    number.toString(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (done) FontWeight.Normal else FontWeight.Medium,
                color = if (done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            )
            if (!done) {
                if (help.isNotEmpty()) {
                    Text(help, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (actionLabel != null) {
                    FilledTonalButton(onClick = onAction, enabled = actionEnabled) { Text(actionLabel) }
                }
            }
        }
    }
}

/** Thin progress bar for "4 of 6 done". */
@Composable
fun ProgressBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f)),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(color),
        )
    }
}

/** "Show all / Show fewer" toggle for collapsible parts. */
@Composable
fun ExpandToggle(label: String, expanded: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onToggle)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
        )
        Icon(
            if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
        )
    }
}

// ------------------------------------------------------------------ drawn glyphs (no icon library needed)

/** Wi-Fi fan. [level] 0–3 = how many arcs are lit. */
@Composable
fun WifiGlyph(color: Color, modifier: Modifier = Modifier, level: Int = 3) {
    val dim = color.copy(alpha = 0.28f)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        // Fits inside its box: outer arc reaches 0.48 of the width each side, 0.165 from the top.
        val baseY = h * 0.82f
        val stroke = h * 0.11f
        for (i in 1..3) {
            val r = h * (0.20f + 0.20f * (i - 1))
            drawArc(
                color = if (i <= level) color else dim,
                startAngle = 225f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(cx - r, baseY - r),
                size = Size(r * 2f, r * 2f),
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
        drawCircle(color = if (level > 0) color else dim, radius = stroke * 0.85f, center = Offset(cx, baseY))
    }
}

/** Mobile signal bars. [level] 0–4 = how many bars are lit. */
@Composable
fun CellGlyph(color: Color, modifier: Modifier = Modifier, level: Int = 4) {
    val dim = color.copy(alpha = 0.28f)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val gap = w * 0.09f
        val barW = (w - gap * 3f) / 4f
        for (i in 0 until 4) {
            val barH = h * (0.34f + 0.66f * i / 3f)
            drawRoundRect(
                color = if (i < level) color else dim,
                topLeft = Offset(i * (barW + gap), h - barH),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barW * 0.35f),
            )
        }
    }
}

/** A simple phone: frame, gradient screen and punch-hole camera. Glyphs are placed on top by the caller. */
@Composable
fun PhoneArt(frame: Color, screenTop: Color, screenBottom: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(color = frame, cornerRadius = CornerRadius(w * 0.2f))
        val inset = w * 0.06f
        drawRoundRect(
            brush = Brush.verticalGradient(colors = listOf(screenTop, screenBottom)),
            topLeft = Offset(inset, inset),
            size = Size(w - inset * 2f, h - inset * 2f),
            cornerRadius = CornerRadius(w * 0.15f),
        )
        drawCircle(color = frame, radius = w * 0.05f, center = Offset(w / 2f, inset + w * 0.11f))
    }
}
