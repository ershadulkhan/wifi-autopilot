package com.ershad.wifiautopilot.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** One thing to allow on this phone so its battery manager doesn't stop the automation. */
data class OemStep(
    val title: String,
    val help: String,
    /** Button text, or null when it has to be done by hand (nothing can be opened). */
    val button: String?,
    val kind: Kind,
    /** Screens tried in order. App info is always the last resort. */
    val screens: List<Intent> = emptyList(),
) {
    enum class Kind { BATTERY, OPEN, MANUAL }
}

/**
 * Per-brand "keep it running" steps. No app can flip these switches itself; each button opens the
 * right screen (screen names differ between versions, so several are tried, then App info).
 */
object OemGuide {

    fun steps(ctx: Context, device: DeviceInfo): List<OemStep> {
        val pkg = ctx.packageName
        val battery = OemStep(
            title = "No battery limits",
            help = "Lets Android keep the automation running in the background.",
            button = "Allow",
            kind = OemStep.Kind.BATTERY,
        )
        val lockInRecents = OemStep(
            title = "Lock the app in Recents",
            help = "Open Recents and pull the Wi-Fi Autopilot card down (or tap its lock), so cleaning up never closes it.",
            button = null,
            kind = OemStep.Kind.MANUAL,
        )
        val appInfoBattery = OemStep(
            title = "Allow background use",
            help = "In App info → Battery (or App battery usage), choose Unrestricted / allow background activity.",
            button = "Open App info",
            kind = OemStep.Kind.OPEN,
        )

        return when (device.family) {
            OemFamily.VIVO -> listOf(
                battery,
                OemStep(
                    "Autostart", "Lets the app start by itself after a restart.", "Open Autostart", OemStep.Kind.OPEN,
                    components(
                        "com.vivo.permissionmanager/com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
                        "com.iqoo.secure/com.iqoo.secure.ui.phoneoptimize.BgStartUpManager",
                        "com.vivo.permissionmanager/com.vivo.permissionmanager.activity.PurviewTabActivity",
                        "com.iqoo.secure/com.iqoo.secure.safeguard.PurviewTabActivity",
                    ),
                ),
                OemStep(
                    "Associated startup", "Lets Android's restart and timer signals wake the app.", "Open", OemStep.Kind.OPEN,
                    listOf(
                        Intent().setComponent(
                            ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.SoftPermissionDetailActivity")
                        ).putExtra("packagename", pkg),
                    ) + components("com.vivo.permissionmanager/com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                ),
                OemStep(
                    "Background power", "Allow high background power use for Wi-Fi Autopilot.", "Open", OemStep.Kind.OPEN,
                    components(
                        "com.vivo.abe/com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity",
                        "com.iqoo.powersaving/com.iqoo.powersaving.PowerSavingManagerActivity",
                        "com.iqoo.secure/com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
                    ),
                ),
                lockInRecents,
            )

            OemFamily.XIAOMI -> listOf(
                battery,
                OemStep(
                    "Autostart", "Lets the app start by itself after a restart.", "Open Autostart", OemStep.Kind.OPEN,
                    components("com.miui.securitycenter/com.miui.permcenter.autostart.AutoStartManagementActivity"),
                ),
                OemStep(
                    "Battery saver: No restrictions", "Stops the battery saver from pausing the app.", "Open", OemStep.Kind.OPEN,
                    listOf(
                        Intent().setComponent(
                            ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")
                        ).putExtra("package_name", pkg).putExtra("package_label", "Wi-Fi Autopilot"),
                    ),
                ),
                lockInRecents,
            )

            OemFamily.OPLUS -> listOf(
                battery,
                OemStep(
                    "Auto launch", "Lets the app start by itself after a restart.", "Open Auto launch", OemStep.Kind.OPEN,
                    components(
                        "com.coloros.safecenter/com.coloros.safecenter.startupapp.StartupAppListActivity",
                        "com.coloros.safecenter/com.coloros.safecenter.permission.startup.StartupAppListActivity",
                        "com.oplus.safecenter/com.oplus.safecenter.startupapp.StartupAppListActivity",
                        "com.oppo.safe/com.oppo.safe.permission.startup.StartupAppListActivity",
                    ),
                ),
                appInfoBattery,
                lockInRecents,
            )

            OemFamily.SAMSUNG -> listOf(
                battery,
                OemStep(
                    "Never sleeping apps",
                    "Battery → Background usage limits → Never sleeping apps → add Wi-Fi Autopilot.",
                    "Open battery settings", OemStep.Kind.OPEN,
                    components("com.samsung.android.lool/com.samsung.android.sm.battery.ui.BatteryActivity"),
                ),
                appInfoBattery,
            )

            OemFamily.HUAWEI, OemFamily.HONOR -> listOf(
                battery,
                OemStep(
                    "App launch: manage manually",
                    "Set Wi-Fi Autopilot to Manage manually and keep all three switches on.",
                    "Open App launch", OemStep.Kind.OPEN,
                    components(
                        "com.huawei.systemmanager/com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
                        "com.huawei.systemmanager/com.huawei.systemmanager.optimize.process.ProtectActivity",
                        "com.hihonor.systemmanager/com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
                    ),
                ),
                lockInRecents,
            )

            OemFamily.TRANSSION -> listOf(
                battery,
                OemStep(
                    "Auto-start", "Lets the app start by itself after a restart.", "Open Auto-start", OemStep.Kind.OPEN,
                    components("com.transsion.phonemaster/com.cyin.himgr.autostart.AutoStartActivity"),
                ),
                lockInRecents,
            )

            OemFamily.ASUS -> listOf(
                battery,
                OemStep(
                    "Auto-start", "Lets the app start by itself after a restart.", "Open Auto-start", OemStep.Kind.OPEN,
                    components(
                        "com.asus.mobilemanager/com.asus.mobilemanager.autostart.AutoStartActivity",
                        "com.asus.mobilemanager/com.asus.mobilemanager.entry.FunctionActivity",
                    ),
                ),
            )

            // Motorola, Pixel, Nothing, Sony, Nokia and others stay close to stock Android:
            // Android's own battery setting is all that matters.
            else -> listOf(battery, appInfoBattery)
        }
    }

    /** Opens the step's screen. Returns false only for manual steps. */
    fun open(ctx: Context, step: OemStep): Boolean = when (step.kind) {
        OemStep.Kind.BATTERY -> Setup.requestIgnoreBatteryOptimizations(ctx)
        OemStep.Kind.OPEN -> step.screens.any { Setup.launch(ctx, it) } || Setup.openAppSettings(ctx)
        OemStep.Kind.MANUAL -> false
    }

    private fun components(vararg flat: String): List<Intent> = flat.mapNotNull { s ->
        ComponentName.unflattenFromString(s)?.let { Intent().setComponent(it) }
    }
}
