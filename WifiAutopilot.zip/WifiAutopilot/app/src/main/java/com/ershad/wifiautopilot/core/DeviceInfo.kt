package com.ershad.wifiautopilot.core

import android.content.Context
import android.os.Build
import android.provider.Settings

/** Phone makers whose battery managers need their own "keep running" steps. */
enum class OemFamily { VIVO, XIAOMI, OPLUS, SAMSUNG, MOTOROLA, GOOGLE, HUAWEI, HONOR, NOTHING, TRANSSION, ASUS, SONY, NOKIA, OTHER }

/**
 * Which phone this is: brand, marketing name ("vivo X200 FE", "motorola edge 60 fusion"), the maker's
 * Android skin ("OriginOS 6", "Hello UI", "One UI 8") and Android version. Read once; needs no permission.
 */
data class DeviceInfo(
    val family: OemFamily,
    /** The brand as it writes itself: "vivo", "Motorola", "Samsung", "Redmi". */
    val brand: String,
    /** Marketing name, e.g. "vivo X200 FE". */
    val name: String,
    /** Build.MODEL, e.g. "V2503". */
    val model: String,
    /** The maker's Android skin, e.g. "OriginOS 6". */
    val skin: String,
    /** "16", "17", … */
    val android: String,
    val sdk: Int,
) {
    /** The model code, when it adds something to the name (hidden when the name already contains it). */
    val modelCode: String? get() = model.takeIf { it.isNotBlank() && !name.contains(it, ignoreCase = true) }

    companion object {
        @Volatile private var cached: DeviceInfo? = null

        fun get(ctx: Context): DeviceInfo = cached ?: read(ctx).also { cached = it }

        // Where makers keep the marketing name. Unreadable ones are simply skipped.
        private val MARKET_NAME_PROPS = listOf(
            "ro.vivo.market.name",
            "ro.product.marketname",
            "ro.product.vendor.marketname",
            "ro.product.odm.marketname",
            "ro.product.system.marketname",
            "ro.vendor.oplus.market.name",
            "ro.oppo.market.name",
            "ro.config.marketing_name",
        )

        private fun read(ctx: Context): DeviceInfo {
            val manufacturer = Build.MANUFACTURER.orEmpty().trim()
            val brandRaw = Build.BRAND.orEmpty().trim().ifEmpty { manufacturer }
            val key = "$manufacturer $brandRaw".lowercase()
            val family = when {
                "vivo" in key || "iqoo" in key -> OemFamily.VIVO
                "xiaomi" in key || "redmi" in key || "poco" in key -> OemFamily.XIAOMI
                "oneplus" in key || "oppo" in key || "realme" in key -> OemFamily.OPLUS
                "samsung" in key -> OemFamily.SAMSUNG
                "motorola" in key || "lenovo" in key -> OemFamily.MOTOROLA
                "google" in key -> OemFamily.GOOGLE
                "huawei" in key -> OemFamily.HUAWEI
                "honor" in key -> OemFamily.HONOR
                "nothing" in key -> OemFamily.NOTHING
                "tecno" in key || "infinix" in key || "itel" in key -> OemFamily.TRANSSION
                "asus" in key -> OemFamily.ASUS
                "sony" in key -> OemFamily.SONY
                "nokia" in key || "hmd" in key -> OemFamily.NOKIA
                else -> OemFamily.OTHER
            }
            val brand = prettyBrand(brandRaw)
            val model = Build.MODEL.orEmpty().trim()

            val fromProps = MARKET_NAME_PROPS.firstNotNullOfOrNull { prop(it) }
            // "Device name" in About phone. It starts as the marketing name, but people can rename it,
            // so it is only trusted when it still looks like the phone's name.
            val deviceName = try {
                Settings.Global.getString(ctx.contentResolver, "device_name")?.trim()?.takeIf { it.isNotEmpty() }
            } catch (e: Throwable) {
                null
            }
            val deviceNameLooksRight = deviceName != null && (
                deviceName.contains(brandRaw, ignoreCase = true) ||
                    deviceName.contains(manufacturer, ignoreCase = true) ||
                    (model.isNotEmpty() && deviceName.contains(model, ignoreCase = true)) ||
                    (family == OemFamily.SAMSUNG && deviceName.startsWith("Galaxy", ignoreCase = true)) ||
                    (family == OemFamily.GOOGLE && deviceName.startsWith("Pixel", ignoreCase = true))
                )
            val name = when {
                fromProps != null -> withBrand(fromProps, brand)
                deviceNameLooksRight -> deviceName!!
                model.isNotEmpty() -> withBrand(model, brand)
                else -> brand.ifEmpty { "Android phone" }
            }

            val sdk = Build.VERSION.SDK_INT
            return DeviceInfo(
                family = family,
                brand = brand,
                name = name,
                model = model,
                skin = skinName(family, key, sdk),
                android = Build.VERSION.RELEASE.orEmpty().ifEmpty { sdk.toString() },
                sdk = sdk,
            )
        }

        private fun withBrand(text: String, brand: String): String =
            if (brand.isEmpty() || text.contains(brand, ignoreCase = true)) text else "$brand $text"

        private fun prettyBrand(raw: String): String = when (raw.lowercase()) {
            "vivo" -> "vivo"
            "iqoo" -> "iQOO"
            "motorola" -> "Motorola"
            "samsung" -> "Samsung"
            "xiaomi" -> "Xiaomi"
            "redmi" -> "Redmi"
            "poco" -> "POCO"
            "oneplus" -> "OnePlus"
            "oppo" -> "OPPO"
            "realme" -> "realme"
            "google" -> "Google"
            "huawei" -> "HUAWEI"
            "honor" -> "HONOR"
            "nothing" -> "Nothing"
            "tecno" -> "TECNO"
            "infinix" -> "Infinix"
            "itel" -> "itel"
            "asus" -> "ASUS"
            "sony" -> "Sony"
            "hmd global", "nokia" -> "Nokia"
            "lenovo" -> "Lenovo"
            else -> raw.replaceFirstChar { it.uppercaseChar() }
        }

        private fun skinName(family: OemFamily, key: String, sdk: Int): String = when (family) {
            OemFamily.VIVO -> vivoSkin(sdk)
            OemFamily.SAMSUNG -> oneUi()
            OemFamily.XIAOMI -> xiaomiSkin()
            OemFamily.OPLUS -> oplusSkin(key)
            OemFamily.MOTOROLA -> if (sdk >= 35) "Hello UI" else "My UX"
            OemFamily.GOOGLE -> "Pixel UI"
            OemFamily.HUAWEI -> prop("ro.build.version.emui")
                ?.substringAfter('_')?.substringBefore('.')?.takeIf { it.isNotEmpty() }
                ?.let { "EMUI $it" } ?: "EMUI"
            OemFamily.HONOR -> "MagicOS"
            OemFamily.NOTHING -> "Nothing OS"
            OemFamily.TRANSSION -> when {
                "tecno" in key -> "HiOS"
                "infinix" in key -> "XOS"
                else -> "itel OS"
            }
            OemFamily.ASUS -> "ZenUI"
            OemFamily.SONY -> "Xperia UI"
            OemFamily.NOKIA, OemFamily.OTHER -> "Android"
        }

        private fun vivoSkin(sdk: Int): String {
            prop("ro.vivo.os.build.display.id")
                ?.takeIf { it.contains("OS", ignoreCase = true) && it.length <= 24 }
                ?.let { return it.replace('_', ' ').trim() }
            val name = prop("ro.vivo.os.name")
            if (name != null) {
                val pretty = if (name.equals("Funtouch", ignoreCase = true)) "Funtouch OS" else name
                val major = prop("ro.vivo.os.version")?.substringBefore('.')?.takeIf { v -> v.all { it.isDigit() } }
                return if (major.isNullOrEmpty()) pretty else "$pretty $major"
            }
            return if (sdk >= 36) "OriginOS" else "Funtouch OS"
        }

        private fun oneUi(): String {
            val v = prop("ro.build.version.oneui")?.toIntOrNull() ?: return "One UI"
            val major = v / 10000
            val minor = (v / 100) % 100
            return if (minor > 0) "One UI $major.$minor" else "One UI $major"
        }

        private fun xiaomiSkin(): String {
            prop("ro.mi.os.version.name")?.let { raw ->
                val version = raw.removePrefix("OS").removeSuffix(".0").trim()
                return if (version.isEmpty()) "HyperOS" else "HyperOS $version"
            }
            prop("ro.miui.ui.version.name")?.let { raw ->
                val digits = raw.filter { it.isDigit() }
                if (digits.length >= 2) {
                    val major = digits.dropLast(1)
                    val minor = digits.last()
                    return if (minor == '0') "MIUI $major" else "MIUI $major.$minor"
                }
            }
            return "HyperOS"
        }

        private fun oplusSkin(key: String): String {
            val base = when {
                "oneplus" in key -> "OxygenOS"
                "realme" in key -> return "realme UI" // realme numbers its own versions differently
                else -> "ColorOS"
            }
            val major = prop("ro.build.version.oplusrom")?.removePrefix("V")?.substringBefore('.')
            return if (major != null && major.isNotEmpty() && major.all { it.isDigit() }) "$base $major" else base
        }

        /** Reads a system property; null when it's missing or this app may not read it. */
        private fun prop(name: String): String? = try {
            val get = Class.forName("android.os.SystemProperties").getMethod("get", String::class.java)
            (get.invoke(null, name) as? String)?.trim()?.takeIf { it.isNotEmpty() }
        } catch (e: Throwable) {
            null
        }
    }
}
