package com.ershad.wifiautopilot.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.ershad.wifiautopilot.BuildConfig
import com.ershad.wifiautopilot.control.DataSafety
import com.ershad.wifiautopilot.control.DualEngineController
import com.ershad.wifiautopilot.control.RadioState
import com.ershad.wifiautopilot.control.ShizukuHelper
import com.ershad.wifiautopilot.control.SystemSettings
import com.ershad.wifiautopilot.core.ActivityLog
import com.ershad.wifiautopilot.core.AutopilotSettings
import com.ershad.wifiautopilot.core.DeviceInfo
import com.ershad.wifiautopilot.core.OemFamily
import com.ershad.wifiautopilot.core.OemGuide
import com.ershad.wifiautopilot.core.OemStep
import com.ershad.wifiautopilot.core.Prefs
import com.ershad.wifiautopilot.core.Setup
import com.ershad.wifiautopilot.core.SystemStatus
import com.ershad.wifiautopilot.service.AutomationForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Result of the one-time setup, shown in a dialog. */
private data class InfoList(val title: String, val lines: List<String>, val footer: String, val offerKeepAlive: Boolean)

/** One core function of the app, as shown in "What works on this phone". */
private class Capability(
    val title: String,
    val detail: String,
    val state: String,
    val tone: Tone,
    val action: String? = null,
    val onAction: () -> Unit = {},
)

/** One setup step. */
private class StepUi(
    val title: String,
    val done: Boolean,
    val help: String,
    val action: String?,
    val onAction: () -> Unit = {},
    val enabled: Boolean = true,
)

private const val DATA_TITLE = "Mobile data switches by itself"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val settings by Prefs.state.collectAsStateWithLifecycle()
    val log by ActivityLog.entries.collectAsStateWithLifecycle()
    val shizuku by ShizukuHelper.state.collectAsStateWithLifecycle()
    val device = remember { DeviceInfo.get(context) }
    val oemSteps = remember(device) { OemGuide.steps(context, device) }
    var status by remember { mutableStateOf(SystemStatus()) }
    var busy by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<InfoList?>(null) }

    fun refresh() {
        scope.launch { status = withContext(Dispatchers.IO) { SystemStatus.read(context) } }
    }

    fun message(text: String) {
        scope.launch { snackbar.showSnackbar(text) }
    }

    // Live dashboard: refresh every 2 seconds while the screen is visible
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                ShizukuHelper.refresh()
                status = withContext(Dispatchers.IO) { SystemStatus.read(context) }
                delay(2_000)
            }
        }
    }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    fun settingsChanged() {
        AutomationForegroundService.engine?.onSettingsChanged()
    }

    fun setAutomation(on: Boolean) {
        Prefs.update { it.copy(automationOn = on) }
        if (on) {
            try {
                AutomationForegroundService.start(context)
            } catch (e: Exception) {
                message("Android blocked the background service: ${e.javaClass.simpleName}")
            }
            when {
                settings.savedSsids.isEmpty() -> message("Now add your Wi-Fi names under My Wi-Fi networks.")
                !status.rebootProof -> message("Automation is on. Finish Setup so it keeps working after a restart.")
            }
        } else {
            AutomationForegroundService.stop(context)
            scope.launch {
                withContext(Dispatchers.IO) {
                    SystemSettings.restoreAlwaysOn(context)
                    DualEngineController.restoreMobileData(context)
                }
                refresh()
            }
            ActivityLog.add("Automation turned off")
        }
        refresh()
    }

    fun addNetworks(names: List<String>) {
        val added = Prefs.addSsids(names)
        if (added.isNotEmpty()) settingsChanged()
        message(if (added.isEmpty()) "Already in your list" else "Added " + added.joinToString(", "))
    }

    /** Runs blocking work off the main thread, then logs and shows its one-line result. */
    fun runInBackground(work: () -> String) {
        busy = true
        scope.launch {
            val text = withContext(Dispatchers.IO) { work() }
            busy = false
            ActivityLog.add(text)
            message(text)
            refresh()
        }
    }

    fun askLocation() {
        if (!status.fineLocation) {
            locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        } else {
            message("Permissions → Location → Allow all the time")
            Setup.openAppSettings(context)
        }
    }

    fun turnOnScanning() {
        scope.launch {
            withContext(Dispatchers.IO) { SystemSettings.ensureSystemFlags(context) }
            if (!status.secureSettings) {
                message("Location → Location services → Wi-Fi scanning: turn it on")
                Setup.openLocationSettings(context)
            }
            refresh()
        }
    }

    fun openShizuku() {
        when (shizuku) {
            ShizukuHelper.State.NOT_INSTALLED -> Setup.openUrl(context, ShizukuHelper.SHIZUKU_RELEASES_URL)
            ShizukuHelper.State.NOT_RUNNING -> if (!Setup.openShizuku(context)) message("Couldn't open Shizuku")
            ShizukuHelper.State.NO_PERMISSION -> if (!ShizukuHelper.requestPermission()) {
                message("In Shizuku, open Authorized applications and turn on Wi-Fi Autopilot")
                Setup.openShizuku(context)
            }
            ShizukuHelper.State.READY -> Unit
        }
    }

    fun keepShizukuAlive() {
        if (!status.secureSettings) {
            message("Turn on USB debugging in Developer options")
            Setup.openDeveloperOptions(context)
            return
        }
        runInBackground {
            if (SystemSettings.keepShizukuAlive(context)) {
                "Done. Shizuku now keeps running when you leave Wi-Fi."
            } else {
                "The phone didn't allow it. Turn on USB debugging in Developer options."
            }
        }
    }

    fun testDataSwitch() = runInBackground { SystemSettings.testSettingsDataSwitch(context) }

    fun runSetup() {
        busy = true
        scope.launch {
            val steps = withContext(Dispatchers.IO) { Setup.runPermanentSetup(context) }
            busy = false
            val now = withContext(Dispatchers.IO) { SystemStatus.read(context) }
            status = now
            val dataWorks = Prefs.current.globalDataSwitch == 1
            val keepAlive = !dataWorks && now.dataVerdict == DataSafety.Verdict.SHIZUKU_WILL_STOP
            info = InfoList(
                title = "One-time setup",
                lines = steps.map { (if (it.ok) "✓  " else "!  ") + it.label },
                footer = when {
                    !steps.first().ok ->
                        "The key permission wasn't granted. Make sure Shizuku says running, then try again."
                    dataWorks ->
                        "Done. Android keeps all of this after every restart. Mobile data switches by itself on " +
                            "this phone, so you can uninstall Shizuku now."
                    keepAlive ->
                        "Done. This phone needs Shizuku to switch mobile data. Tap Keep Shizuku alive so it " +
                            "survives leaving Wi-Fi, or uninstall Shizuku and data will just pause on Wi-Fi."
                    else ->
                        "Done. Android keeps all of this after every restart. This phone needs Shizuku to " +
                            "switch mobile data off. Without it, data stays on but isn't used on Wi-Fi."
                },
                offerKeepAlive = keepAlive,
            )
            settingsChanged()
        }
    }

    val capabilities = capabilities(
        s = status,
        settings = settings,
        shizuku = shizuku,
        device = device,
        askLocation = { askLocation() },
        openLocation = { Setup.openLocationSettings(context) },
        turnOnScanning = { turnOnScanning() },
        openAppInfo = { Setup.openAppSettings(context) },
        allowBattery = { Setup.requestIgnoreBatteryOptimizations(context) },
        keepShizukuAlive = { keepShizukuAlive() },
        openShizuku = { openShizuku() },
        testDataSwitch = { testDataSwitch() },
        startService = {
            try {
                AutomationForegroundService.start(context)
            } catch (e: Exception) {
                message("Android blocked the background service")
            }
            refresh()
        },
        removeOldEntry = { runInBackground { if (SystemSettings.removeOldAccessibilityEntry(context)) "Old accessibility entry removed" else "Nothing to remove" } },
    )
    val setupSteps = setupSteps(
        s = status,
        shizuku = shizuku,
        busy = busy,
        askLocation = { askLocation() },
        turnOnScanning = { turnOnScanning() },
        notifications = { Setup.openNotificationSettings(context) },
        openShizuku = { openShizuku() },
        runSetup = { runSetup() },
        testDataSwitch = { testDataSwitch() },
        keepShizukuAlive = { keepShizukuAlive() },
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text("Wi-Fi Autopilot", fontWeight = FontWeight.SemiBold) }) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { DeviceHeader(device, status) }
            item { AutomationCard(settings, status, onToggle = { setAutomation(it) }) }

            item { SectionTitle("Right now") }
            item { NowSection(status, settings) }

            item { SectionTitle("What works on this phone", "${capabilities.count { it.tone == Tone.Good }} of ${capabilities.size} working") }
            item {
                Group {
                    capabilities.forEachIndexed { i, c ->
                        if (i > 0) GroupDivider()
                        CapabilityRow(c.title, c.detail, c.state, c.tone, c.action, !busy, c.onAction)
                    }
                }
            }

            item { SectionTitle("Setup", "${setupSteps.count { it.done }} of ${setupSteps.size} done") }
            item { SetupGroup(setupSteps) }

            item { SectionTitle("Keep it running on ${device.brand}") }
            item {
                OemGroup(device, oemSteps, status.batteryUnrestricted, shizuku != ShizukuHelper.State.NOT_INSTALLED) { step ->
                    if (!OemGuide.open(context, step)) message("Couldn't open that screen. Use App info instead.")
                }
            }

            item { SectionTitle("My Wi-Fi networks", if (settings.savedSsids.isEmpty()) null else settings.savedSsids.size.toString()) }
            item {
                NetworksGroup(
                    ssids = settings.savedSsids,
                    currentSsid = status.ssid,
                    shizukuReady = shizuku == ShizukuHelper.State.READY,
                    onAdd = { addNetworks(listOf(it)) },
                    onRemove = {
                        Prefs.removeSsid(it)
                        settingsChanged()
                    },
                    onImport = {
                        busy = true
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { RadioState.importSavedNetworks() }
                            busy = false
                            result.fold(
                                onSuccess = { names ->
                                    if (names.isEmpty()) message("No saved Wi-Fi networks found on the phone") else addNetworks(names)
                                },
                                onFailure = { e -> message(e.message ?: "Import failed") },
                            )
                        }
                    },
                )
            }

            item { SectionTitle("Mobile data") }
            item {
                MobileDataGroup(settings) { updated ->
                    Prefs.update { updated }
                    settingsChanged()
                }
            }

            item { SectionTitle("Fine-tuning") }
            item {
                TuningGroup(settings) { updated ->
                    Prefs.update { updated }
                    settingsChanged()
                }
            }

            item { SectionTitle("Try it") }
            item {
                TryGroup(
                    busy = busy,
                    onLeave = {
                        runInBackground {
                            val w = DualEngineController.setWifi(context, false)
                            val d = DualEngineController.setMobileData(context, true)
                            "Test leaving: Wi-Fi off ${describe(w)}, mobile data on ${describe(d)}"
                        }
                    },
                    onArrive = {
                        runInBackground {
                            val w = DualEngineController.setWifi(context, true)
                            "Test arriving: Wi-Fi on ${describe(w)}"
                        }
                    },
                    onScan = {
                        val saved = settings.savedSsids
                        runInBackground { RadioState.scanReport(context, saved) }
                    },
                )
            }

            item { SectionTitle("Activity log", if (log.isEmpty()) null else log.size.toString()) }
            item { LogGroup(log, onClear = { ActivityLog.clear() }) }

            item {
                Text(
                    "Wi-Fi Autopilot ${BuildConfig.VERSION_NAME}\nby Md Ershadul Haque Khan",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                )
            }
        }
    }

    val shown = info
    if (shown != null) {
        AlertDialog(
            onDismissRequest = { info = null },
            confirmButton = { TextButton(onClick = { info = null }) { Text("OK") } },
            dismissButton = if (shown.offerKeepAlive) {
                {
                    TextButton(onClick = {
                        info = null
                        keepShizukuAlive()
                    }) { Text("Keep Shizuku alive") }
                }
            } else {
                null
            },
            title = { Text(shown.title) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    shown.lines.forEach { line -> Text(line, style = MaterialTheme.typography.bodyMedium) }
                    Spacer(Modifier.height(6.dp))
                    Text(shown.footer, style = MaterialTheme.typography.bodySmall)
                }
            },
        )
    }
}

private fun describe(r: DualEngineController.Result): String = when (r.outcome) {
    DualEngineController.Outcome.DONE -> "(done, ${r.via})"
    DualEngineController.Outcome.FAILED -> "(didn't work: ${r.via})"
}

// ------------------------------------------------------------------ what works on this phone

private fun capabilities(
    s: SystemStatus,
    settings: AutopilotSettings,
    shizuku: ShizukuHelper.State,
    device: DeviceInfo,
    askLocation: () -> Unit,
    openLocation: () -> Unit,
    turnOnScanning: () -> Unit,
    openAppInfo: () -> Unit,
    allowBattery: () -> Unit,
    keepShizukuAlive: () -> Unit,
    openShizuku: () -> Unit,
    testDataSwitch: () -> Unit,
    startService: () -> Unit,
    removeOldEntry: () -> Unit,
): List<Capability> {
    val wifi = when {
        !s.nativeWifiSwitch -> Capability(
            "Wi-Fi switches by itself", "This Android version doesn't let apps switch Wi-Fi.", "Not possible", Tone.Bad,
        )
        settings.wifiSwitch == -1 -> Capability(
            "Wi-Fi switches by itself",
            "The phone refused last time. If it asked whether Wi-Fi Autopilot may turn on WLAN, allow it in App info.",
            "Blocked", Tone.Warn, "Open App info", openAppInfo,
        )
        else -> Capability(
            "Wi-Fi switches by itself",
            "Off when you leave, back on near your saved Wi-Fi. Needs no Shizuku.",
            "Works", Tone.Good,
        )
    }

    val finds = when {
        !s.fineLocation || !s.backgroundLocation -> Capability(
            "Spots your Wi-Fi while it's off",
            "Allow location all the time. Android hides Wi-Fi names from apps without it.",
            "Needs location", Tone.Warn, "Allow", askLocation,
        )
        !s.locationOn -> Capability(
            "Spots your Wi-Fi while it's off",
            "Turn Location on. Android only scans for Wi-Fi while it's on.",
            "Location off", Tone.Warn, "Open settings", openLocation,
        )
        !s.wifiScanningOn -> Capability(
            "Spots your Wi-Fi while it's off",
            "Turn on Wi-Fi scanning so the phone can see networks while Wi-Fi is off.",
            "Scanning off", Tone.Warn, "Turn on", turnOnScanning,
        )
        settings.savedSsids.isEmpty() -> Capability(
            "Spots your Wi-Fi while it's off",
            "Add your Wi-Fi names under My Wi-Fi networks.",
            "No networks", Tone.Warn,
        )
        else -> Capability(
            "Spots your Wi-Fi while it's off",
            "Watches for ${settings.savedSsids.size} saved network" + (if (settings.savedSsids.size == 1) "" else "s") +
                ", mostly using scans Android already does.",
            "Ready", Tone.Good,
        )
    }

    val data = when {
        !settings.turnDataOffOnWifi -> Capability(
            DATA_TITLE,
            "Turned off under Mobile data below. Data stays on; Android still pauses it on Wi-Fi.",
            "Off", Tone.Neutral,
        )
        s.dataVerdict == DataSafety.Verdict.SETTINGS_OK -> Capability(
            DATA_TITLE, "Off on Wi-Fi, back on when you leave. This phone needs no Shizuku for it.", "Works", Tone.Good,
        )
        s.dataVerdict == DataSafety.Verdict.SHIZUKU_OK -> Capability(
            DATA_TITLE,
            "Shizuku switches it and keeps running when you leave Wi-Fi. After a phone restart, open Shizuku once.",
            "Works", Tone.Good,
        )
        s.dataVerdict == DataSafety.Verdict.SHIZUKU_WILL_STOP -> Capability(
            DATA_TITLE,
            "Android stops Shizuku when you leave Wi-Fi because USB debugging is off, so data couldn't come back on. " +
                "Until this is fixed, data stays on and is only paused on Wi-Fi.",
            "Needs a fix", Tone.Bad, "Keep Shizuku alive", keepShizukuAlive,
        )
        !s.secureSettings -> Capability(
            DATA_TITLE, "Finish the one-time setup below first.", "Not set up", Tone.Warn,
        )
        s.dataSwitchTest == 0 -> Capability(
            DATA_TITLE, "Not tested on this phone yet.", "Not tested", Tone.Warn, "Test now", testDataSwitch,
        )
        shizuku == ShizukuHelper.State.NOT_RUNNING || shizuku == ShizukuHelper.State.NO_PERMISSION -> Capability(
            DATA_TITLE,
            "On this phone it needs Shizuku running. Until you start it, data stays on and is only paused on Wi-Fi.",
            "Shizuku stopped", Tone.Warn,
            if (shizuku == ShizukuHelper.State.NO_PERMISSION) "Allow access" else "Open Shizuku", openShizuku,
        )
        else -> Capability(
            DATA_TITLE,
            "This phone needs Shizuku to flip the switch. Without it, data stays on but isn't used while Wi-Fi works.",
            "Paused only", Tone.Neutral,
        )
    }

    val restart = when {
        !s.secureSettings || !s.rebootProof -> Capability(
            "Keeps working after a restart", "Finish Setup below.", "Not yet", Tone.Warn,
        )
        !s.batteryUnrestricted -> Capability(
            "Keeps working after a restart",
            "Allow no battery limits so ${device.brand} doesn't stop it.",
            "Battery limits", Tone.Warn, "Allow", allowBattery,
        )
        else -> Capability(
            "Keeps working after a restart", "Starts by itself after every restart, before you even unlock.", "Yes", Tone.Good,
        )
    }

    val background = when {
        !settings.automationOn -> Capability(
            "Runs in the background", "Turn on Automation at the top.", "Off", Tone.Neutral,
        )
        s.serviceRunning -> Capability(
            "Runs in the background",
            "A quiet notification keeps it alive. It only reacts to changes, so it barely uses battery.",
            "Running", Tone.Good,
        )
        else -> Capability(
            "Runs in the background",
            "${device.brand} stopped it. Start it again and check Keep it running below.",
            "Stopped", Tone.Bad, "Start", startService,
        )
    }

    val bank = if (s.oldAccessibilityEntry) {
        Capability(
            "Safe for banking apps",
            "An accessibility entry from an old version is still on. Banking apps such as bKash object to it.",
            "Old entry", Tone.Warn, "Remove", removeOldEntry,
        )
    } else {
        Capability(
            "Safe for banking apps", "No accessibility service, so bKash and other banking apps work normally.", "Yes", Tone.Good,
        )
    }

    return listOf(wifi, finds, data, restart, background, bank)
}

// ------------------------------------------------------------------ setup

private fun setupSteps(
    s: SystemStatus,
    shizuku: ShizukuHelper.State,
    busy: Boolean,
    askLocation: () -> Unit,
    turnOnScanning: () -> Unit,
    notifications: () -> Unit,
    openShizuku: () -> Unit,
    runSetup: () -> Unit,
    testDataSwitch: () -> Unit,
    keepShizukuAlive: () -> Unit,
): List<StepUi> {
    val shizukuReady = shizuku == ShizukuHelper.State.READY
    val adbLine = "No Shizuku? From a computer with USB debugging on, run once: " +
        "adb shell pm grant com.ershad.wifiautopilot android.permission.WRITE_SECURE_SETTINGS"

    val dataStep = when {
        s.dataSwitchTest == 1 -> StepUi(
            "Mobile data on this phone", true, "", null,
        )
        s.dataVerdict == DataSafety.Verdict.SHIZUKU_OK -> StepUi(
            "Mobile data on this phone", true, "", null,
        )
        s.dataSwitchTest == -1 && shizuku == ShizukuHelper.State.NOT_INSTALLED -> StepUi(
            "Mobile data on this phone", true, "", null,
        )
        s.dataVerdict == DataSafety.Verdict.SHIZUKU_WILL_STOP -> StepUi(
            "Keep Shizuku alive",
            false,
            "This phone needs Shizuku to switch mobile data. Android stops Shizuku when you leave Wi-Fi unless " +
                "USB debugging is on, so turn it on here. Or uninstall Shizuku and data will just pause on Wi-Fi.",
            "Keep Shizuku alive", keepShizukuAlive, !busy,
        )
        s.dataSwitchTest == -1 -> StepUi(
            "Mobile data on this phone",
            false,
            "This phone needs Shizuku running to switch mobile data off. Start it, then come back here. " +
                "Or uninstall Shizuku and data will just pause on Wi-Fi.",
            if (shizuku == ShizukuHelper.State.NO_PERMISSION) "Allow access" else "Open Shizuku", openShizuku, !busy,
        )
        else -> StepUi(
            "Mobile data on this phone",
            false,
            "The one-time setup tests this automatically. You can also test it now.",
            "Test now", testDataSwitch, s.secureSettings && !busy,
        )
    }

    return listOf(
        StepUi(
            "Allow location all the time",
            s.fineLocation && s.backgroundLocation,
            "Android hides Wi-Fi names and scan results from apps without it.",
            if (!s.fineLocation) "Allow location" else "Allow all the time",
            askLocation,
        ),
        StepUi(
            "Turn on Location and Wi-Fi scanning",
            s.locationOn && s.wifiScanningOn && s.wifiWakeOn,
            "Lets the phone spot your Wi-Fi while the Wi-Fi button is off.",
            "Turn on", turnOnScanning,
        ),
        StepUi(
            "Allow notifications",
            s.notifications,
            "For the quiet status notification and the occasional warning.",
            "Allow", notifications,
        ),
        StepUi(
            "Start Shizuku (one time)",
            s.secureSettings || shizukuReady,
            when (shizuku) {
                ShizukuHelper.State.NOT_INSTALLED -> "Install the free Shizuku app, open it and tap Start. "
                ShizukuHelper.State.NOT_RUNNING -> "Open Shizuku and tap Start. "
                ShizukuHelper.State.NO_PERMISSION -> "Shizuku is running. Let Wi-Fi Autopilot use it. "
                ShizukuHelper.State.READY -> ""
            } + adbLine,
            when (shizuku) {
                ShizukuHelper.State.NOT_INSTALLED -> "Get Shizuku"
                ShizukuHelper.State.NOT_RUNNING -> "Open Shizuku"
                ShizukuHelper.State.NO_PERMISSION -> "Allow access"
                ShizukuHelper.State.READY -> null
            },
            openShizuku,
        ),
        StepUi(
            "Run the one-time setup",
            s.secureSettings && s.wifiWakeOn && s.backgroundLocation && s.dataSwitchTest != 0,
            "Grants a permanent permission, removes battery limits and tests how this phone switches mobile data." +
                if (!shizukuReady && !s.secureSettings) " Needs Shizuku running." else "",
            if (busy) "Working…" else "Run one-time setup",
            runSetup,
            (shizukuReady || s.secureSettings) && !busy,
        ),
        dataStep,
    )
}

@Composable
private fun SetupGroup(steps: List<StepUi>) {
    val done = steps.count { it.done }
    val allDone = done == steps.size
    var open by rememberSaveable { mutableStateOf(false) }
    Group(Modifier.animateContentSize()) {
        Spacer(Modifier.height(8.dp))
        ProgressBar(done.toFloat() / steps.size, MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(2.dp))
        if (allDone) {
            GroupNote("All set. Android keeps every one of these after a restart.")
            ExpandToggle(if (open) "Hide steps" else "Show steps", open) { open = !open }
        }
        if (!allDone || open) {
            steps.forEachIndexed { i, step ->
                if (i > 0) GroupDivider()
                StepRow(i + 1, step.title, step.done, step.help, step.action, step.onAction, step.enabled)
            }
        }
    }
}

// ------------------------------------------------------------------ header

@Composable
private fun DeviceHeader(device: DeviceInfo, s: SystemStatus) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val onWifi = s.wifiConnected
        Box(Modifier.size(width = 60.dp, height = 112.dp), contentAlignment = Alignment.Center) {
            PhoneArt(
                frame = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.82f),
                screenTop = if (onWifi) WifiBright else DataBright,
                screenBottom = if (onWifi) WifiDeep else DataDeep,
                modifier = Modifier.fillMaxSize(),
            )
            if (onWifi) {
                WifiGlyph(Color.White, Modifier.size(26.dp))
            } else {
                CellGlyph(Color.White, Modifier.size(22.dp), level = if (s.cellularActive) 4 else 1)
            }
        }
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(device.brand, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                device.name,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Fact("Android ${device.android}")
                Fact(device.skin)
            }
            val code = device.modelCode
            if (code != null) {
                Text("Model $code", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------------ automation (look kept from 5.0)

@Composable
private fun AutomationCard(settings: AutopilotSettings, s: SystemStatus, onToggle: (Boolean) -> Unit) {
    val on = settings.automationOn
    val container = if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val content = if (on) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    val dataOnArrival = when {
        !settings.turnDataOffOnWifi -> "mobile data stays on"
        DataSafety.mayTurnDataOff(s.dataVerdict) -> "mobile data off"
        else -> "mobile data paused"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = container, contentColor = content),
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Automation", style = MaterialTheme.typography.labelLarge)
                    Text(
                        if (on) "ON" else "OFF",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Switch(checked = on, onCheckedChange = onToggle)
            }
            Spacer(Modifier.height(16.dp))
            RuleRow(
                icon = { WifiGlyph(content, Modifier.size(20.dp), level = 1) },
                trigger = "When you leave Wi-Fi",
                result = "Wi-Fi off, mobile data on",
                content = content,
            )
            Spacer(Modifier.height(10.dp))
            RuleRow(
                icon = { Icon(Icons.Filled.Home, contentDescription = null, tint = content, modifier = Modifier.size(20.dp)) },
                trigger = "When you reach a saved Wi-Fi",
                result = "Wi-Fi on, $dataOnArrival",
                content = content,
            )
            Spacer(Modifier.height(16.dp))
            val (tone, line) = when {
                !on -> Tone.Neutral to "Off. Turn it on to let the app switch for you."
                settings.savedSsids.isEmpty() -> Tone.Warn to "Add your Wi-Fi names below so it knows where home is."
                !s.rebootProof -> Tone.Warn to "Finish Setup below so it keeps working after a restart."
                !s.serviceRunning -> Tone.Warn to "Not running right now. See What works below."
                else -> Tone.Good to "Running, and keeps running after restarts."
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                ToneIcon(tone, Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(line, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun RuleRow(icon: @Composable () -> Unit, trigger: String, result: String, content: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(50))
                .background(content.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) { icon() }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(trigger, style = MaterialTheme.typography.bodySmall, color = content.copy(alpha = 0.8f))
            Text(result, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ------------------------------------------------------------------ right now

@Composable
private fun NowSection(s: SystemStatus, settings: AutopilotSettings) {
    var open by rememberSaveable { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val wifiState = when {
                s.wifiConnected -> "Connected"
                s.wifiOn -> "On"
                else -> "Off"
            }
            val wifiDetail = when {
                s.wifiConnected -> (s.ssid ?: "Name hidden") + if (s.wifiInternet) "" else ", no internet yet"
                s.wifiOn -> "Looking for a network"
                settings.automationOn && settings.savedSsids.isNotEmpty() -> "Watching for your Wi-Fi"
                else -> "Not in use"
            }
            ConnectionTile(
                modifier = Modifier.weight(1f),
                active = s.wifiConnected,
                accent = wifiColor(),
                container = MaterialTheme.colorScheme.secondaryContainer,
                onContainer = MaterialTheme.colorScheme.onSecondaryContainer,
                glyph = { c -> WifiGlyph(c, Modifier.size(30.dp), level = if (s.wifiConnected) 3 else if (s.wifiOn) 1 else 0) },
                label = "Wi-Fi",
                state = wifiState,
                detail = wifiDetail,
            )
            val dataState = when (s.mobileData) {
                true -> if (s.cellularActive) "In use" else if (s.wifiConnected) "Paused" else "On"
                false -> "Off"
                null -> "Unknown"
            }
            val dataDetail = when {
                s.mobileData == null -> "No SIM found"
                s.mobileData == false && s.wifiConnected -> "Switched off on Wi-Fi"
                s.mobileData == false -> "Switched off. No internet."
                s.cellularActive -> "Your internet right now"
                s.wifiConnected -> "Not used while Wi-Fi works"
                else -> "Waiting for signal"
            }
            ConnectionTile(
                modifier = Modifier.weight(1f),
                active = s.cellularActive,
                accent = dataColor(),
                container = MaterialTheme.colorScheme.tertiaryContainer,
                onContainer = MaterialTheme.colorScheme.onTertiaryContainer,
                glyph = { c -> CellGlyph(c, Modifier.size(28.dp), level = if (s.cellularActive) 4 else if (s.mobileData == true) 2 else 0) },
                label = "Mobile data",
                state = dataState,
                detail = dataDetail,
            )
        }
        if (s.airplane) {
            Surface(shape = RoundedCornerShape(16.dp), color = toneColor(Tone.Warn).copy(alpha = 0.14f)) {
                Text(
                    "Airplane mode is on. Automation waits until it's off.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = toneColor(Tone.Warn),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                )
            }
        }
        Group(Modifier.animateContentSize()) {
            ExpandToggle(if (open) "Hide details" else "Show all details", open) { open = !open }
            if (open) {
                StatusRow("Wi-Fi radio", if (s.wifiOn) "On" else "Off", if (s.wifiOn) Tone.Good else Tone.Neutral)
                StatusRow(
                    "Internet over Wi-Fi",
                    if (!s.wifiConnected) "Not connected" else if (s.wifiInternet) "Confirmed" else "Not confirmed",
                    if (s.wifiInternet) Tone.Good else Tone.Neutral,
                )
                StatusRow(
                    "Mobile data switch",
                    when (s.mobileData) {
                        true -> "On"
                        false -> "Off"
                        null -> "Unknown"
                    },
                    if (s.mobileData == true) Tone.Good else Tone.Neutral,
                )
                StatusRow("Cellular connection", if (s.cellularActive) "In use" else "Not in use", if (s.cellularActive) Tone.Good else Tone.Neutral)
                StatusRow("Cellular pauses on Wi-Fi", if (s.cellularPausesOnWifi) "Yes" else "No", if (s.cellularPausesOnWifi) Tone.Good else Tone.Neutral)
                StatusRow("Location", if (s.locationOn) "On" else "Off", if (s.locationOn) Tone.Good else Tone.Bad)
                StatusRow("Wi-Fi scanning while off", if (s.wifiScanningOn) "On" else "Off", if (s.wifiScanningOn) Tone.Good else Tone.Bad)
                StatusRow("Android's auto Wi-Fi", if (s.wifiWakeOn) "On" else "Off", if (s.wifiWakeOn) Tone.Good else Tone.Warn)
                StatusRow("Permanent permission", if (s.secureSettings) "Granted" else "Not yet", if (s.secureSettings) Tone.Good else Tone.Bad)
                StatusRow("Developer options", if (s.developerOptions) "On" else "Off", Tone.Neutral)
                StatusRow("USB debugging", if (s.usbDebugging) "On" else "Off", Tone.Neutral)
                StatusRow(
                    "Shizuku",
                    s.shizukuVersion?.let { "Installed $it" } ?: "Not installed",
                    Tone.Neutral,
                )
                StatusRow("Background service", if (s.serviceRunning) "Running" else "Stopped", if (s.serviceRunning) Tone.Good else Tone.Neutral)
                StatusRow("Battery limits", if (s.batteryUnrestricted) "None" else "On", if (s.batteryUnrestricted) Tone.Good else Tone.Warn)
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

@Composable
private fun ConnectionTile(
    modifier: Modifier,
    active: Boolean,
    accent: Color,
    container: Color,
    onContainer: Color,
    glyph: @Composable (Color) -> Unit,
    label: String,
    state: String,
    detail: String,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(28.dp),
        color = if (active) container else MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Column(Modifier.padding(16.dp)) {
            glyph(if (active) accent else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                color = if (active) onContainer else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                state,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = if (active) onContainer else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = if (active) onContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ------------------------------------------------------------------ brand steps

@Composable
private fun OemGroup(
    device: DeviceInfo,
    steps: List<OemStep>,
    batteryUnrestricted: Boolean,
    shizukuInstalled: Boolean,
    onOpen: (OemStep) -> Unit,
) {
    val stock = device.family in setOf(OemFamily.MOTOROLA, OemFamily.GOOGLE, OemFamily.NOTHING, OemFamily.SONY, OemFamily.NOKIA, OemFamily.OTHER)
    Group {
        GroupNote(
            "Detected ${device.name} with ${device.skin}. " + if (stock) {
                "It stays close to plain Android, so Android's own battery setting is what matters."
            } else {
                "${device.brand} phones close background apps to save battery. Allow these once."
            }
        )
        steps.forEach { step ->
            GroupDivider()
            val done = step.kind == OemStep.Kind.BATTERY && batteryUnrestricted
            CapabilityRow(
                title = step.title,
                detail = step.help,
                state = when {
                    done -> "Done"
                    step.kind == OemStep.Kind.BATTERY -> "Needed"
                    step.kind == OemStep.Kind.MANUAL -> "By hand"
                    else -> ""
                },
                tone = when {
                    done -> Tone.Good
                    step.kind == OemStep.Kind.BATTERY -> Tone.Warn
                    else -> Tone.Neutral
                },
                actionLabel = if (done) null else step.button,
                onAction = { onOpen(step) },
            )
        }
        if (shizukuInstalled) {
            GroupDivider()
            GroupNote("Keeping Shizuku? Give Shizuku the same permissions, so ${device.brand} doesn't close it either.")
        }
    }
}

// ------------------------------------------------------------------ networks

@Composable
private fun NetworksGroup(
    ssids: List<String>,
    currentSsid: String?,
    shizukuReady: Boolean,
    onAdd: (String) -> Unit,
    onRemove: (String) -> Unit,
    onImport: () -> Unit,
) {
    var text by rememberSaveable { mutableStateOf("") }
    fun submit() {
        val name = text.trim()
        if (name.isNotEmpty()) {
            onAdd(name)
            text = ""
        }
    }
    Group {
        if (ssids.isEmpty()) {
            GroupNote("Add the exact names of Home, Office and so on. Wi-Fi turns back on when one of them is nearby.")
        }
        ssids.forEachIndexed { i, name ->
            if (i > 0) GroupDivider()
            val connected = currentSsid != null && name.equals(currentSsid, ignoreCase = true)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                WifiGlyph(wifiColor(), Modifier.size(22.dp), level = if (connected) 3 else 2)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (connected) {
                        Text("Connected now", style = MaterialTheme.typography.labelMedium, color = wifiColor())
                    }
                }
                IconButton(onClick = { onRemove(name) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Remove $name", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            label = { Text("Wi-Fi name, exactly as shown") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { submit() }),
            trailingIcon = {
                IconButton(onClick = { submit() }, enabled = text.isNotBlank()) {
                    Icon(Icons.Filled.Add, contentDescription = "Add")
                }
            },
        )
        Spacer(Modifier.height(8.dp))
        if (currentSsid != null && ssids.none { it.equals(currentSsid, ignoreCase = true) }) {
            OutlinedButton(onClick = { onAdd(currentSsid) }, modifier = Modifier.fillMaxWidth()) {
                Text("Add “$currentSsid” (connected now)", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        OutlinedButton(onClick = onImport, enabled = shizukuReady, modifier = Modifier.fillMaxWidth()) {
            Text("Import saved networks from this phone")
        }
        if (!shizukuReady) {
            GroupNote("Importing needs Shizuku running. Typing names works without it.")
        } else {
            Spacer(Modifier.height(10.dp))
        }
    }
}

// ------------------------------------------------------------------ mobile data, tuning, try it

@Composable
private fun MobileDataGroup(s: AutopilotSettings, onChange: (AutopilotSettings) -> Unit) {
    Group {
        SwitchRow(
            title = "Switch mobile data off on Wi-Fi",
            help = "Back on by itself when you leave, and before the phone restarts.",
            checked = s.turnDataOffOnWifi,
            onChange = { onChange(s.copy(turnDataOffOnWifi = it)) },
        )
        GroupDivider()
        SwitchRow(
            title = "Only once the Wi-Fi has internet",
            help = "Recommended. Never leaves you on a Wi-Fi that has no internet.",
            checked = s.dataOffNeedsInternet,
            onChange = { onChange(s.copy(dataOffNeedsInternet = it)) },
        )
    }
}

@Composable
private fun SwitchRow(title: String, help: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(help, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TuningGroup(s: AutopilotSettings, onChange: (AutopilotSettings) -> Unit) {
    var grace by remember(s.graceSeconds) { mutableFloatStateOf(s.graceSeconds.toFloat()) }
    var interval by remember(s.scanIntervalMin) { mutableFloatStateOf(s.scanIntervalMin.toFloat()) }
    var rssi by remember(s.minRssi) { mutableFloatStateOf(s.minRssi.toFloat()) }
    Group {
        SliderLabel("Wait before switching to mobile data", "${grace.roundToInt()} s")
        Slider(
            value = grace,
            onValueChange = { grace = it },
            valueRange = 3f..30f,
            steps = 26,
            onValueChangeFinished = { onChange(s.copy(graceSeconds = grace.roundToInt())) },
        )
        GroupDivider()
        SliderLabel("Look for your Wi-Fi every", "${interval.roundToInt()} min")
        Text(
            "Also when you move, change cell tower or wake the screen.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Slider(
            value = interval,
            onValueChange = { interval = it },
            valueRange = 1f..15f,
            steps = 13,
            onValueChangeFinished = { onChange(s.copy(scanIntervalMin = interval.roundToInt())) },
        )
        GroupDivider()
        SliderLabel("Weakest Wi-Fi signal to switch on for", "${rssi.roundToInt()} dBm (${signalWord(rssi.roundToInt())})")
        Slider(
            value = rssi,
            onValueChange = { rssi = it },
            valueRange = -90f..-55f,
            steps = 6,
            onValueChangeFinished = { onChange(s.copy(minRssi = rssi.roundToInt())) },
        )
    }
}

@Composable
private fun SliderLabel(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Fact(value)
    }
}

private fun signalWord(dbm: Int): String = when {
    dbm >= -60 -> "strong"
    dbm >= -70 -> "good"
    dbm >= -80 -> "fair"
    else -> "weak"
}

@Composable
private fun TryGroup(busy: Boolean, onLeave: () -> Unit, onArrive: () -> Unit, onScan: () -> Unit) {
    Group {
        Spacer(Modifier.height(10.dp))
        Button(onClick = onLeave, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Simulate leaving")
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = onArrive, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Simulate arriving")
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = onScan, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Scan now for my networks")
        }
        GroupNote(
            "Leaving turns Wi-Fi off and mobile data on. At home with Automation on, Wi-Fi then comes back by itself " +
                "within seconds: that's the arrival rule working. If the phone asks whether Wi-Fi Autopilot may turn " +
                "on WLAN, choose Always allow."
        )
    }
}

// ------------------------------------------------------------------ activity log (collapsible)

@Composable
private fun LogGroup(entries: List<ActivityLog.Entry>, onClear: () -> Unit) {
    var open by rememberSaveable { mutableStateOf(false) }
    Group(Modifier.animateContentSize()) {
        if (entries.isEmpty()) {
            GroupNote("Nothing yet. Every automatic switch shows up here.")
        } else {
            val shown = if (open) entries.take(80) else entries.take(3)
            shown.forEachIndexed { i, e ->
                if (i > 0) GroupDivider()
                Column(Modifier.padding(vertical = 9.dp)) {
                    Text(formatTime(e.time), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(e.text, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (entries.size > 3) {
                GroupDivider()
                ExpandToggle(if (open) "Show fewer" else "Show all ${minOf(entries.size, 80)}", open) { open = !open }
            }
            TextButton(onClick = onClear) { Text("Clear log") }
        }
    }
}

private fun formatTime(millis: Long): String {
    val then = Calendar.getInstance().apply { timeInMillis = millis }
    val now = Calendar.getInstance()
    val sameDay = then.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
        then.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "'Today' HH:mm:ss" else "d MMM, HH:mm:ss"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
}
